// 
// Decompiled by Procyon v0.6.0
// 

package LoginWindow;

public class LoginWindow
{
    public void setVisible(final boolean b) {
    }
}
