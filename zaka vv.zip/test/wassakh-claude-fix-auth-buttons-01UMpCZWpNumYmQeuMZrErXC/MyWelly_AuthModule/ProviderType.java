// 
// Decompiled by Procyon v0.6.0
// 

enum ProviderType
{
    DOCTOR, 
    LABORATORY;
}
