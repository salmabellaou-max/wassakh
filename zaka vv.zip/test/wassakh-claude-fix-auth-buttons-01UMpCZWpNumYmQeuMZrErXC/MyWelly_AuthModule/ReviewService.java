import java.sql.SQLException;
import java.util.List;

class ReviewService {

    public Long addReview(Long patientId, Long providerId, ProviderType providerType,
                         Long appointmentId, Integer rating, String comment) throws SQLException {
        // TODO: Decompilation failed - implementation needs to be recovered
        throw new UnsupportedOperationException("Method not yet decompiled");
    }

    public List<Review> getProviderReviews(Long providerId, ProviderType providerType) throws SQLException {
        // TODO: Decompilation failed - implementation needs to be recovered
        throw new UnsupportedOperationException("Method not yet decompiled");
    }
}
