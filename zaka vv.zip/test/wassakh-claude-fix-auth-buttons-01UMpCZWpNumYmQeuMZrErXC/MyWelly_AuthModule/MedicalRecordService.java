import java.sql.SQLException;
import java.util.List;

class MedicalRecordService {

    public Long addMedicalRecord(Long patientId, Long appointmentId, RecordType recordType,
                                String diagnosis, String prescription, String notes,
                                ProviderType providerType, Long providerId) throws SQLException {
        // TODO: Decompilation failed - implementation needs to be recovered
        throw new UnsupportedOperationException("Method not yet decompiled");
    }

    public List<MedicalRecord> getPatientRecords(Long patientId) throws SQLException {
        // TODO: Decompilation failed - implementation needs to be recovered
        throw new UnsupportedOperationException("Method not yet decompiled");
    }
}
