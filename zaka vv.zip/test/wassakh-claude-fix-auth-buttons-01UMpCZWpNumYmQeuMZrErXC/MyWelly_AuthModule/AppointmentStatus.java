// 
// Decompiled by Procyon v0.6.0
// 

enum AppointmentStatus
{
    SCHEDULED, 
    COMPLETED, 
    CANCELLED_BY_PATIENT, 
    CANCELLED_BY_DOCTOR, 
    NO_SHOW;
}
