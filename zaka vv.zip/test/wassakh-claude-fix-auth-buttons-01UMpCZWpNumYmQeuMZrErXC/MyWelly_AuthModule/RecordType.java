// 
// Decompiled by Procyon v0.6.0
// 

enum RecordType
{
    CONSULTATION_REPORT, 
    LAB_RESULT, 
    PRESCRIPTION, 
    DIAGNOSIS, 
    RADIOLOGY_REPORT;
}
