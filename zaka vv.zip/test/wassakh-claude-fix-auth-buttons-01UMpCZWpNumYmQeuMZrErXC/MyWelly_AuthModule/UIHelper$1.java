import java.awt.event.MouseEvent;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.MouseAdapter;

// 
// Decompiled by Procyon v0.6.0
// 

class UIHelper$1 extends MouseAdapter {
    final /* synthetic */ Color val$bgColor;
    final /* synthetic */ JButton val$button;
    Color originalBg;

    public UIHelper$1(Color val$bgColor, JButton val$button) {
        this.val$bgColor = val$bgColor;
        this.val$button = val$button;
        this.originalBg = this.val$bgColor;
    }

    @Override
    public void mouseEntered(final MouseEvent e) {
        this.val$button.setBackground(UIConstants.HOVER_GREEN);
    }

    @Override
    public void mouseExited(final MouseEvent e) {
        this.val$button.setBackground(this.originalBg);
    }
}
