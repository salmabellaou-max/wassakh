// 
// Decompiled by Procyon v0.6.0
// 

enum VerificationPurpose
{
    SIGNUP, 
    PASSWORD_RESET, 
    EMAIL_CHANGE;
}
